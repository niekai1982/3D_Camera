import cv2
import numpy as np
import os
import glob
import matplotlib as mpl
from calibrate import CalibrationData
import open3d as o3d

mpl.use("tkagg")
import matplotlib.pyplot as plt
from pattern_decode import decode_gray_set
from cv2python import *

THRESHOLD_DEFAULT = 25
MAX_DIST_DEFAULT = 200.
projector_size = cvSize(1024, 768)

calib = CalibrationData()
calib.cam_K = np.array([[1.34108783e+03, 0.00000000e+00, 7.57647206e+02],
                        [0.00000000e+00, 1.36529204e+03, 5.90305029e+02],
                        [0.00000000e+00, 0.00000000e+00, 1.00000000e+00]], dtype=np.float32)
calib.cam_kc = np.array([[0.056331],
                         [-0.14330043],
                         [0.00049911],
                         [0.00587907],
                         [-0.04140769]], dtype=np.float32)
calib.proj_K = np.array([[1.14625724e+03, 0.00000000e+00, 5.18094559e+02],
                         [0.00000000e+00, 2.30183195e+03, 9.03357861e+02],
                         [0.00000000e+00, 0.00000000e+00, 1.00000000e+00]], dtype=np.float32)
calib.proj_kc = np.array([[-1.03377180e-01],
                          [1.81623434e-01],
                          [1.17968871e-03],
                          [2.78020677e-04],
                          [-6.04080295e-01]], dtype=np.float32)
calib.R = np.array([[0.91218621, 0.02915611, -0.40873737],
                    [-0.09185049, 0.98663306, -0.13460568],
                    [0.39934922, 0.16032817, 0.90267108]], dtype=np.float32)
calib.T = np.array([[151.97529507],
                    [-53.07685352],
                    [281.33812854]], dtype=np.float32)
calib.is_valid = True


def triangulate_stereo(K1, kc1, K2, kc2, Rt, T, p1, p2, distance):
    inp1 = np.empty(shape=(1, 1, 2), dtype=np.float64)
    inp2 = np.empty(shape=(1, 1, 2), dtype=np.float64)
    inp1[0, 0, 0] = p1[0]
    inp1[0, 0, 1] = p1[1]
    inp2[0, 0, 0] = p2[0]
    inp2[0, 0, 1] = p2[1]
    outp1 = cv2.undistortPoints(inp1, K1, kc1)
    outp2 = cv2.undistortPoints(inp2, K2, kc2)

    outvec1 = outp1[0, 0]
    outvec2 = outp2[0, 0]
    u1 = np.array([outvec1[0], outvec1[1], 1.0])
    u2 = np.array([outvec2[0], outvec2[1], 1.0])
    u1.shape = -1, 1
    u2.shape = -1, 1
    w1 = u1
    w2 = np.matmul(Rt, (u2 - T))

    v1 = w1
    v2 = np.matmul(Rt, u2)

    p3d, distance, _, _ = approximate_ray_intersection(v1, w1, v2, w2, distance)
    return p3d, distance


def approximate_ray_intersection(v1, q1, v2, q2, distance, out_lambda1=0, out_lambda2=0):
    v1mat = np.array(v1)
    v2mat = np.array(v2)
    v1tv1 = np.matmul(v1mat.T, v1mat)
    v2tv2 = np.matmul(v2mat.T, v2mat)
    v1tv2 = np.matmul(v1mat.T, v2mat)
    v2tv1 = np.matmul(v2mat.T, v1mat)

    Vinv = np.empty(shape=(2, 2), dtype=np.float64)
    detV = v1tv1 * v2tv2 - v1tv2 * v2tv1
    Vinv[0, 0] = v2tv2 / detV
    Vinv[0, 1] = v1tv2 / detV
    Vinv[1, 0] = v2tv1 / detV
    Vinv[1, 1] = v1tv1 / detV

    q2_q1 = q2 - q1

    Q1 = v1[0] * q2_q1[0] + v1[1] * q2_q1[1] + v1[2] * q2_q1[2]
    Q2 = -(v2[0] * q2_q1[0] + v2[1] * q2_q1[1] + v2[2] * q2_q1[2])

    lambda1 = (v2tv2 * Q1 + v1tv2 * Q2) / detV
    lambda2 = (v2tv1 * Q1 + v1tv1 * Q2) / detV

    p1 = lambda1 * v1 + q1
    p2 = lambda2 * v2 + q2

    p = 0.5 * (p1 + p2)

    distance = cv2.norm(p2 - p1)
    if out_lambda1:
        out_lambda1 = lambda1
    if out_lambda2:
        out_lambda2 = lambda2
    return p, distance, out_lambda1, out_lambda2


def reconstruct_model_simple(pattern_list):
    # pattern_image, min_max_image = decode_gray_set(pattern_list)
    pattern_image = np.load('./2013-May-14_20.41.56117_pattern_image.npy')
    min_max_image = np.load('./2013-May-14_20.41.56117_min_max_image.npy')
    color_image = cv2.imread(pattern_list[0])
    threshold = THRESHOLD_DEFAULT
    max_dist = MAX_DIST_DEFAULT

    plane_dist = 100.0
    scale_factor = 1
    out_cols = int(pattern_image.shape[1])
    out_rows = int(pattern_image.shape[0])
    pointcloud = np.empty(shape=(out_rows, out_cols, 3))

    Rt = calib.R.T

    good = 0
    bad = 0
    invalid = 0
    repeated = 0

    for h in range(pattern_image.shape[0]):
        for w in range(pattern_image.shape[1]):
            distance = max_dist
            pattern = pattern_image[h, w]
            min_max = min_max_image[h, w]
            if np.isnan(pattern[0]) or np.isnan(pattern[1]) or pattern[0] < 0. or pattern[1] < 0. or (
                    min_max[1] - min_max[0]) < threshold:
                invalid += 1
                continue
            col = pattern[0]
            row = pattern[1]

            if projector_size.width <= int(col) or projector_size.height <= int(row):
                continue

            p1 = (w, h)
            p2 = (col, row)

            p, distance = triangulate_stereo(calib.cam_K, calib.cam_kc, calib.proj_K, calib.proj_kc, Rt, calib.T, p1,
                                             p2, distance)

            if distance < max_dist:
                d = plane_dist + 1
                if d > plane_dist:
                    pointcloud[h, w][0] = p[0][0]
                    pointcloud[h, w][1] = p[1][0]
                    pointcloud[h, w][2] = p[2][0]
    return pointcloud


if __name__ == '__main__':
    pattern_file_list = glob.glob('../cartman/2013-May-14_20.41.56.117/*.png')
    pattern_file_list.sort()
    count = len(pattern_file_list)
    out = reconstruct_model_simple(pattern_file_list)
    np.save('./2013-May-14_20.41.56117_reconstruct.npy', out)
    xyz = np.zeros((out.shape[0] * out.shape[1], 3), dtype=np.float32)

    xyz[:,  0] = out[:, :, 1].flatten()
    xyz[:,  1] = out[:, :, 0].flatten()
    xyz[:,  2] = out[:, :, 2].flatten()
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(xyz)
    o3d.io.write_point_cloud("./sync.ply", pcd)
